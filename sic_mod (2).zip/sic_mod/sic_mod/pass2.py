

def getformat(instruction):
    global opinst
    f = 0
    for i in range(len(inst)):
        if inst[i][0].upper() == instruction[1]:
            f = inst[i][1]
            opinst = inst[i][2]
        elif len(instruction) > 2:
            if inst[i][0].upper() == instruction[2]:
                f = inst[i][1]
                opinst = inst[i][2]
    return f


)

    if f == '34':
        if len(instruction) > 2:
            if instruction[-1][0] == '#':
                opcode = str("%02x" % (int(opinst, 16)*2 + 1)).split('x')[-1].upper()
            else:
                opcode = str("%02x" % (int(opinst, 16)*2)).split('x')[-1].upper()
            flagx = 0

            for j in range(0, len(sim)):
                if instruction[-1][-1].upper() == 'X' and instruction[-1][-2].upper() == ',':
                    if instruction[-1].split(',')[0].split('#')[-1].upper() == sim[j][1]:
                        simvalue = sim[j][0]
                        flagx = 1
                else:
                    if instruction[-1].split('#')[-1].upper() == sim[j][1]:
                        simvalue = sim[j][0]

            if simvalue == '0' and instruction[-1][0] == '#':
                opcode = opcode + str("%04x" % int(instruction[-1].split('#')[-1])).upper()
            elif flagx == 1:
                opcode = opcode + str("%04x" % int("0b" + '1' + str(bin(int(simvalue,16))).split('b')[-1].zfill(15), 2)).split('x')[-1].upper()
            else:
                opcode = opcode + str("%04x" % int("0b" + '0' + str(bin(int(simvalue,16))).split('b')[-1].zfill(15), 2)).split('x')[-1].upper()




        else:
            opcode = str("%02x" % (int(opinst, 16) + 3)).split('x')[-1].upper() + '0000'

    return opcode






    first: str = pass1.get_first_address()
    Hrec = "H." + '{0: <6}'.format(OUT[0][1]).replace(" ", "_") + "." + '{0: <6}'.format(first).replace(" ",
                                                                                                         "0") + "." + \
           str("%06x" % (int(OUT[len(OUT) - 1][0], 16) - int(first, 16))).split('x')[-1].upper()
    # print(Hrec)

    Erec = "E." + '{0: <6}'.format(first).replace(" ", "0")
    # print(Erec)

    # print(rec)
    opp = ''
    Trecarr = []
    g = 0
    for t in range(1, len(Finalarr) - 1):
        r = str(Finalarr[t + 1])
        if len(opp + Finalarr[t][-1].replace("_", "")) <= 60 and r.find('RESW') == -1 and r.find(
                'RESB') == -1 and r.find('END\'') == -1:
            opp = opp + Finalarr[t][-1].replace("_", "").replace(" ", "")

        else:
            if r.find('RESW') != -1 or r.find('RESB') != -1 or r.find('END\'') != -1:
                opp = opp + Finalarr[t][-1].replace("_", "")
            if opp != "":
                addersss = str("%06x" % int(Finalarr[g][0], 16)).split('x')[-1].upper()
                Trec = "T." + addersss + "." + str("%02x" % int(len(opp) / 2)).split('x')[-1].upper() + "." + opp
                Trecarr.append(Trec)
            if len(opp + '{0: <6}'.format(Finalarr[t][-1]).replace("_", "")):
                g = t
                opp = '{0: <6}'.format(Finalarr[t][-1]).replace("_", "").replace(" ", "")
            if not (len(opp + '{0: <6}'.format(Finalarr[t][-1]).replace("_", "")) <= 60 and r.find(
                    'RESW') == -1 and r.find('RESB') == -1 and r.find('END\'') == -1):
                opp = ''
                g = t + 2
    # print(Trec
    #
    #
    #
    #
    #
    # arr)
    filerec = open("rec.txt", "w")
    filerec.close()
    filerec = open("rec.txt", "a")
    filerec.write(Hrec + "\n")
    for k in range(0, len(Trecarr)):
        filerec.write(Trecarr[k] + "\n")
    filerec.write(Erec + "\n")
    filerec.close()


pass2()
