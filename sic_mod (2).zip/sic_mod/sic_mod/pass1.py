with open("program.txt") as program:
    prog = [line.split() for line in program]
with open("instructions.txt") as instructions:
    inst = [line.split() for line in instructions]



def get_first_address():
    fa = '0'
    for i in range(0, len(prog)):
        if len(prog[i]) > 2:
            if prog[i][1].upper() == 'START':
                fa = prog[i][2]

    return fa


pc = int(get_first_address(), 16)


def getformat(instruction):
    f = 0
    for i in range(len(inst)):
        if inst[i][0].upper() == instruction[0]:
            f = inst[i][1]
        elif len(instruction) > 1:
            if inst[i][0].upper() == instruction[1]:
                f = inst[i][1]
    return f


def get_pc(f, pc, i):
    if f == 0:
        if prog[i][1].upper() == 'BYTE':
            if prog[i][2][0].upper() == 'C':
                pc = pc + int(len(prog[i][2]) - 3)
            elif prog[i][2][0].upper() == 'X':
                if (len(prog[i][2]) - 3) % 2 == 0:
                    pc = pc + int(len(prog[i][2]) - 3) / 2
                elif (len(prog[i][2]) - 3) % 2 == 1:
                    pc = pc + int(len(prog[i][2]) - 3 + 1) / 2
            else:
                pc = pc + 1
        elif prog[i][1].upper() == 'WORD':
            pc = pc + 3
        elif prog[i][1].upper() == 'RESB':
            if prog[i][2][0].upper() == 'X':
                pc = pc + int(str(prog[i][2]).split('\'')[1], 16)
            else:
                pc = pc + int(prog[i][2])
        elif prog[i][1].upper() == 'RESW':
            if prog[i][2][0].upper() == 'X':
                pc = pc + int(str(prog[i][2]).split('\'')[1], 16) * 3
            else:
                pc = pc + int(prog[i][2]) * 3
    elif f == '1':
        pc = pc + 1
    elif f == '34':
        pc = pc + 3
    return pc


def Creat_OUT_table():
    fileOUT = open("OUT.txt", "w")
    fileOUT.close()


def in_OUT_table(i, loc, z):
    global pc
    fileOUT = open("OUT.txt", "a")
    if z == 0:
        if len(prog[i]) > 2:
            fileOUT.write(loc + "\t" + prog[i][0] + "\t" + prog[i][1] + "\t" + prog[i][2] + "\n")
        elif len(prog[i]) > 1:
            fileOUT.write(loc + "\t" + prog[i][0] + "\t" + prog[i][1] + "\n")
        else:
            fileOUT.write(loc + "\t" + prog[i][0] + "\n")

    fileOUT.close()


def Creat_sim_table():
    filesim = open("sim.txt", "w")
    filesim.close()


def in_sim_table(i, loc):
    flag = 0
    for j in range(len(inst)):
        if inst[j][0] == prog[i][0]:
            flag = 1
    if flag == 0:
        filesim = open("sim.txt", "a")
        filesim.write(loc + "\t" + prog[i][0] + "\n")
        filesim.close()


def pass1():
    global pc
    Creat_OUT_table()
    Creat_sim_table()
    z = 0
    for i in range(0, len(prog)):
        loc = hex(int(pc)).split('x')[-1].upper()
        in_OUT_table(i, loc, z)
        in_sim_table(i, loc)
        f = getformat(prog[i])
        pc = get_pc(f, pc, i)

pass1()
